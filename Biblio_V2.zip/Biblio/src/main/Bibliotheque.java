package main;

import documents.Documents;

import java.util.ArrayList;

public class Bibliotheque {
    public static Documents[] documents=null;

}
