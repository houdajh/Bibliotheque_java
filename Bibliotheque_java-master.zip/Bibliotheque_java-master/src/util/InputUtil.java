package util;


import com.company.Documents;
import com.company.Livre;
import gestion.Etudiant;
import gestion.Personne;

import java.util.Scanner;

public class InputUtil {
    public static int enterInt(String title){
        System.out.println(title);
        Scanner scanner=new Scanner(System.in);
        int operation=scanner.nextInt();
        return operation;
    }
    public static String enterString(String title){
        System.out.println(title);
        Scanner scanner=new Scanner(System.in);
        String answer=scanner.nextLine();
        return answer;
    }
    public static Documents fill(){

        int ISBN=InputUtil.enterInt("enter ISBN\n");
        String titre =InputUtil.enterString("enter titre\n");
        String auteurs =InputUtil.enterString("enter auteur\n");
        String editeurs =InputUtil.enterString("enter editeur\n");
        int ann_edition=InputUtil.enterInt("enter annee d'edition\n");
        int nb_exp=InputUtil.enterInt("enter annee d'edition\n");
        return new Documents(ISBN,titre,auteurs,editeurs,ann_edition,nb_exp);
    }
    public static Personne fillE(){

        String genre=InputUtil.enterString("enter le genre\n");
        String nom =InputUtil.enterString("enter le nom\n");
        String prenom =InputUtil.enterString("enter le prenom\n");
        String profession =InputUtil.enterString("enter profession\n");
        String cne=InputUtil.enterString("enter CNE\n");
        int nb_liv=InputUtil.enterInt("enter nombre de livre emprunte\n");
        return new Personne(genre,nom ,prenom, profession, nb_liv);
    }


}
