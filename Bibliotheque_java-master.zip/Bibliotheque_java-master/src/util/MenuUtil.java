package util;


import com.company.Bibliotheque;
import com.company.Documents;
import gestion.Etudiant;
import gestion.Personne;
import gestion.Professeur;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuUtil {
    public static void printAllDocument() {
        if (Bibliotheque.documents == null) {
            System.out.println("you do not have any Documents\n");
            return;
        }
        System.out.println("Documents that you have registred:\n");
        for (int i = 0; i < Bibliotheque.documents.length; i++) {
            Documents doc = Bibliotheque.documents[i];
            System.out.println((1 + i) + ".Document\n" + doc.getInfo());
        }
    }

    //booleanAjouterDocument(Document d)
    public static boolean AjouterDocument() {
        int count = InputUtil.enterInt("how many documents do you want to register?\n");
        Bibliotheque.documents = new Documents[count];// Bibliotheque.documents est un obj d un tab students
        boolean add = false;
        for (int i = 0; i < count; i++) {
            System.out.println((i + 1) + "-Register");
            Documents doc = InputUtil.fill();
            Bibliotheque.documents[i] = doc;
            add = true;
        }
        return add;
    }

    //Document[] getDocumentsByEditeur(String Editeur)
    public static void findDocuments_editeur() {
        String editeur = InputUtil.enterString("enter editeur of document that you want to find ;\n");
        for (int i = 0; i < Bibliotheque.documents.length; i++) {
            Documents doc = Bibliotheque.documents[i];
            if (doc.getEditeur().equalsIgnoreCase(editeur)) {
                System.out.println(doc.getInfo());
            } else {
                System.out.println("Student not found\n");
            }

        }
    }

    public static void findDocuments_titre() {
        String title = InputUtil.enterString("enter title of document that you want to find ;\n");
        for (int i = 0; i < Bibliotheque.documents.length; i++) {
            Documents doc = Bibliotheque.documents[i];
            if (doc.getTitre().equalsIgnoreCase(title)) {
                System.out.println(doc.getInfo());
            } else {
                System.out.println("Document not found\n");
            }

        }
    }

    public static void findDocuments_ISBN() {
        int ISBN = InputUtil.enterInt("enter ISBN of document that you want to find ;\n");
        for (int i = 0; i < Bibliotheque.documents.length; i++) {
            Documents doc = Bibliotheque.documents[i];
            if (doc.getISBN() == ISBN) {
                System.out.println(doc.getInfo());
            } else {
                System.out.println("Document not found\n");
            }

        }
    }

    public static void findDocuments_auteur() {
        String auteur = InputUtil.enterString("enter auteur of document that you want to find ;\n");
        for (int i = 0; i < Bibliotheque.documents.length; i++) {
            Documents doc = Bibliotheque.documents[i];
            if (doc.getTitre().equalsIgnoreCase(auteur)) {
                System.out.println(doc.getInfo());
            } else {
                System.out.println("Document not found\n");
            }

        }
    }

    public static void updateDocument() {
        int update = InputUtil.enterInt("In which Student you want to update:\n");
        System.out.println("Enter new information:\n");
        Documents doc = InputUtil.fill();
        Bibliotheque.documents[update - 1] = doc;
        System.out.println(doc.getInfo());
    }

    //Etudiant getEtudiantByCne(String cne)
    public static void getEtudiantByCne(String cne) {
        System.out.println("enter cne of student that you want to find ");
        for (int i = 0; i < Bibliotheque.emprunteurs.length; i++) {
            Etudiant etud = (Etudiant) Bibliotheque.emprunteurs[i];
            if (etud.getCne().equalsIgnoreCase(cne)) {
                System.out.println(etud.toString());
            } else {
                System.out.println("Student not found\n");
            }

        }
    }

    //Professeur getProfesseurByCin(String cin)
    public static void getProfesseurByCin(String cin) {
        System.out.println("enter cin of Professor that you want to find ");
        for (int i = 0; i < Bibliotheque.emprunteurs.length; i++) {
            Professeur pro = (Professeur) Bibliotheque.emprunteurs[i];
            if (pro.getCin().equalsIgnoreCase(cin)) {
                System.out.println(pro.toString());
            } else {
                System.out.println("Professor not found\n");
            }

        }
    }

    //boolean_SupprimerEtudiant(String cne)
    public static boolean SupprimerEtudiant(String cne) {
        List<Etudiant> listE = new ArrayList<Etudiant>();
        for (Etudiant e : listE) {
            if (e.getCne().equalsIgnoreCase(cne)) {
                int i = listE.indexOf(e);
                listE.remove(i);
                return true;
            }
        }
        return false;
    }

    //booleanSupprimerProfesseur(String cin)
    public static boolean SupprimerProfesseur(String cin) {
        List<Professeur> listP = new ArrayList<Professeur>();
        for (Professeur p : listP) {
            if (p.getCin().equalsIgnoreCase(cin)) {
                int j = listP.indexOf(p);
                listP.remove(j);
                return true;
            }
        }
        return false;
    }

    //booleanAjouterAdherent(Adherent a)
   /* public static boolean AjouterAdherent(Personne a) {
        boolean add=false;
        Personne std= InputUtil.fillE();
        int count = InputUtil.enterInt("Do you want to add :   1-Student     2-Professor  :\n");
        if (count==1){
            Bibliotheque.emprunteurs=new Etudiant[1];


    }*/
}





