package util;

public class Mail {
}
