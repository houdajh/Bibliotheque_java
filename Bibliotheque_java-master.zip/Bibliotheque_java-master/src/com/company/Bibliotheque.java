package com.company;

import gestion.Etudiant;
import gestion.Personne;

import java.util.*;

public class Bibliotheque {
    public static Documents[] documents;
    public static Personne[] emprunteurs;




    public Bibliotheque() {
    }



}
