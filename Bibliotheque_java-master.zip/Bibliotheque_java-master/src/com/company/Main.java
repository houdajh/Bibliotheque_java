package com.company;
import com.company.Bibliotheque;
import util.InputUtil;
import util.MenuUtil;

import java.util.Enumeration;

public class Main {

    public static void main(String[] args) {
        System.out.println("Welcome to our bibliotheque");
        while (true) {
            int operation = InputUtil.enterInt("what do you want to do?" +
                    "\n1-Register Document" +
                    "\n2-show all Document" +
                    "\n3-Find Document by editeur" +
                    "\n3-Find Document by title" +
                    "\n4-Update Document" +
                    "\n0-To Quit");
            switch (operation) {
                case 1: {
                    MenuUtil.AjouterDocument();
                    break;
                }
                case 2:  {
                    MenuUtil.printAllDocument();
                    break;
                }
                case 3:  {
                    MenuUtil.findDocuments_editeur();
                    break;
                }
                case 4: {
                    MenuUtil.updateDocument();
                    break;
                }
                case 0:{
                    System.out.println("Quiting from the system!\n");
                    break;

                }

            }
        }



    }
}