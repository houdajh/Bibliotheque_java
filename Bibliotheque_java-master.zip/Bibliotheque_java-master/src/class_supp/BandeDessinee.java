package class_supp;

public class BandeDessinee {
}
