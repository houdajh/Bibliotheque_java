package gestion;


import com.company.Livre;

public class Etudiant extends Personne {
    private String cne;
    private Livre liv_emprunte;

    public Etudiant(String genre, String nom ,String prenom, String profession,String cne,Livre Liv_emprunte, int nb_liv) {
        super(genre,nom,prenom, profession, nb_liv);
        this.cne= cne;
        this.liv_emprunte=liv_emprunte;
    }


    public String getCne() {
        return cne;
    }
    public Livre getLiv_emprunte() {
        return liv_emprunte;
    }

    public void setCne(String cne) {
        this.cne = cne;
    }

    public void setLiv_emprunte(Livre liv_emprunte) {
        this.liv_emprunte = liv_emprunte;
    }
}
