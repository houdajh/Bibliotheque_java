package gestion;


import com.company.Livre;

public class Personne  {
    private String genre;
    private String nom;
    private String prenom;
    private String profession;
    private int nb_liv;


    public Personne(String genre, String nom ,String prenom, String profession, int nb_liv) {
        this.genre = genre;
        this.nom = nom;
        this.prenom = prenom;
        this.profession = profession;
        this.nb_liv=nb_liv;
    }

    public String getGenre() {
        return genre;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getProfession() {
        return profession;
    }

        public int getNb_liv() {
        if(nb_liv==1 || nb_liv==0) {
            return nb_liv;
        }
        return -1;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }


    public void setNb_liv(int nb_liv) {
        this.nb_liv = nb_liv;
    }
}