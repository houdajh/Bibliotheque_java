package main;

import documents.Documents;
import util.InputUtil;
import util.MenuUtil;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to the school operation Centre");
        while (true) {
            int operation = InputUtil.enterInt("what do you want to do?" +
                    "\n1-Register Documents" +
                    "\n2-show all Documents" +
                    "\n3-Find Document" +
                    "\n4-Update Document" +
                    "\n5-Delete Document" +
                    "\n0-To Quit");
            switch (operation) {
                case 1: {
                    MenuUtil.registerDocument();
                    break;
                }
                case 2:  {
                    MenuUtil.printAllDoc();
                    break;
                }
                case 3:  {
                    MenuUtil.findDocument_title();
                    break;
                }
                case 4: {
                    MenuUtil.updateDoc();
                    break;
                }
                case 5: {
                    MenuUtil.suppDocument();
                    break;
                }
                case 0:{
                    System.out.println("Quiting from the system!\n");
                    return;

                }

            }
        }



    }
}
