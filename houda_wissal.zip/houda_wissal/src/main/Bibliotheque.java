package main;


import Personne.Personne;
import documents.Documents;

import java.util.*;

public class Bibliotheque {
    public static Documents[] documents;
    public static Personne[] emprunteurs;







}
