package util;

import Personne.Etudiant;
import Personne.Professeur;
import Personne.Personne;
import documents.Documents;
import main.Bibliotheque;

public class MenuUtil_Per {
    public static void printAllEmp(){
        if(Bibliotheque.emprunteurs==null){
            System.out.println("you do not have any emp\n");
            return;
        }
        System.out.println("Personne that you have :\n");
        for (int i=0;i<Bibliotheque.emprunteurs.length;i++){
            Personne P= Bibliotheque.emprunteurs[i];
            System.out.println((1+i)+".document\n"+P.toString());
        }
    }
    public static void registerEmp(){
        int count=InputUtil.enterInt("how many Adherent do you want to register?\n");
        Bibliotheque.emprunteurs=new Personne[count];
        for (int i=0;i<count;i++){
            System.out.println((i+1)+"-Register");
            Personne P=InputUtil.fillE();
            Bibliotheque.emprunteurs[i]=P;
        }
    }
    public static void  getEtudiantByCne(){
        String find=InputUtil.enterString("enter CNE that you want to find ;\n");
        for (int i = 0; i< Bibliotheque.emprunteurs.length; i++){
            Etudiant st=(Etudiant) Bibliotheque.emprunteurs[i];
            if(st.getCne().equalsIgnoreCase(find) ){
                System.out.println(st.toString());
            }
            else {
                System.out.println("Document not found\n");
            }

        }
    }
    //Professeur getProfesseurByCin(String cin)
    public static void getProfesseurByCin(String cin) {
        System.out.println("enter cin of Professor that you want to find ");
        for (int i = 0; i < Bibliotheque.emprunteurs.length; i++) {
            Professeur pro = (Professeur) Bibliotheque.emprunteurs[i];
            if (pro.getCin().equalsIgnoreCase(cin)) {
                System.out.println(pro.toString());
            } else {
                System.out.println("Professor not found\n");
            }

        }
    }

}
