package util;

import documents.Documents;
import main.Bibliotheque;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

public class MenuUtil {
    public static void printAllDoc(){
        if(Bibliotheque.documents==null){
            System.out.println("you do not have any Documents\n");
            return;
        }
        System.out.println("Documents that you have registred:\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents doc= Bibliotheque.documents[i];
            System.out.println((1+i)+".document\n"+doc.getInfo());
        }
    }
    public static void registerDocument(){
        int count=InputUtil.enterInt("how many documents do you want to register?\n");
        Bibliotheque.documents=new Documents[count];// Bibliotheque.documents est un obj d un tab students
        for (int i=0;i<count;i++){
            System.out.println((i+1)+"-Register");
            Documents doc=InputUtil.fill();//st obj dyal student
            Bibliotheque.documents[i]=doc;
        }
    }
    public static void suppDocument() {
        if (Bibliotheque.documents == null) {
            System.out.println("you do not have any Documents\n");
            return;
        }
        int i=0;
        String title = InputUtil.enterString("title of documents that you want to delete?\n");
        for (Documents doc : Bibliotheque.documents) {

            if (doc.getTitre().equalsIgnoreCase(title)) {
                continue;
            }
            Bibliotheque.documents[i]=doc;
            i++;
        }


    }
    public static void findDocument_title(){
        String find=InputUtil.enterString("enter title that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents doc= Bibliotheque.documents[i];
            if(doc.getTitre().equalsIgnoreCase(find) ){
                System.out.println(doc.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }

        }
    }
    public static void findDocument_aut(){
        String find=InputUtil.enterString("enter auteur that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents st= Bibliotheque.documents[i];
            if(st.getAuteurs().equalsIgnoreCase(find) ){
                System.out.println(st.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }

        }
    }
    public static void findDocument_ISBN(){
        int find=InputUtil.enterInt("enter ISBN that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents doc= Bibliotheque.documents[i];
            if(doc.getISBN()==find ){
                System.out.println(doc.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }

        }
    }
    public static void updateDoc(){
        int update=InputUtil.enterInt("In which Document you want to update:\n");
        System.out.println("Enter new information:\n");
        Documents st=InputUtil.fill();
        Bibliotheque.documents[update-1]=st;
        System.out.println(st.getInfo());
    }

}
