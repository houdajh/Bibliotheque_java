package Personne;

import documents.Livre;

public class Professeur extends Personne {

    private String cin;
    private Livre liv_emprunte;

    public Professeur(String genre, String nom ,String prenom, String profession, Livre liv_emprunte, int nb_liv, String cin) {
        super(genre,nom,prenom, profession,nb_liv);
        this.cin= cin;
        this.liv_emprunte= liv_emprunte;
    }

    public String getCin() {
        return cin;
    }
    public Livre getLiv_emprunte() {
        return liv_emprunte;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }
    public void setLiv_emprunte(Livre liv_emprunte) {
        this.liv_emprunte = liv_emprunte;
    }
}

