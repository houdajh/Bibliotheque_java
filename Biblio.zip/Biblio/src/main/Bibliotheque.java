package main;

import documents.Documents;

public class Bibliotheque {
    public static Documents[] documents=null;
}
