package util;

import Personne.Etudiant;

import Personne.Personne;

import main.Bibliotheque;

import java.util.Arrays;

public class MenuUtil_Etu {
    public static void printAllEmp(){
        if(Bibliotheque.emprunteursE==null){
            System.out.println("you do not have any emp\n");
            return;
        }
        System.out.println("Student that you have :\n");
        for (int i=0;i<Bibliotheque.emprunteursE.length;i++){
            Personne P= Bibliotheque.emprunteursE[i];
            System.out.println((1+i)+".document\n"+P.toString());
        }
    }
    public static void registerEmpEtu(){
        int count=InputUtil.enterInt("how many Adherent do you want to register?\n");
        Bibliotheque.emprunteursE=new Etudiant[count];
        for (int i=0;i<count;i++){
            System.out.println((i+1)+"-Register");
            Etudiant E=InputUtil.fillE();
            Bibliotheque.emprunteursE[i]=E;
        }
    }
    public static void  getEtudiantByCne() {
        String find = InputUtil.enterString("enter CNE that you want to find ;\n");
        for (int i = 0; i < Bibliotheque.emprunteursE.length; i++) {
            Etudiant st = (Etudiant) Bibliotheque.emprunteursE[i];
            if (st.getCne().equalsIgnoreCase(find)) {
                System.out.println(st.toString());
            } else {
                System.out.println("Document not found\n");
            }
        }
    }
        public static void suppEtudiant() {
            if (Bibliotheque.emprunteursE == null) {
                System.out.println("you do not have any Student\n");
                return;
            }
            Etudiant[] etuArray= Arrays.copyOf(Bibliotheque.emprunteursE,Bibliotheque.emprunteursE.length);
            String cne = InputUtil.enterString("Cne of student that you want to delete?\n");
            for (Etudiant e : etuArray) {
                if (e!=null &&e.getCne().equalsIgnoreCase(cne)) {
                    int i= e.getArrayIndexE(Bibliotheque.emprunteursE,e );
                    Bibliotheque.emprunteursE[i]=null;

                    System.out.println("Student has been deleted");
                }
            }
        }
    }



