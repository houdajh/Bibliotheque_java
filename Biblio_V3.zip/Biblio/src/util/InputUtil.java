package util;


import Personne.Etudiant;
import Personne.Professeur;
import Personne.Personne;
import documents.Documents;
import documents.Livre;
import main.Bibliotheque;

import java.util.Scanner;

;

public class InputUtil {
    public static int enterInt(String title){
        System.out.println(title);
        Scanner scanner=new Scanner(System.in);
        int operation=scanner.nextInt();
        return operation;
    }
    public static String enterString(String title){
        System.out.println(title);
        Scanner scanner=new Scanner(System.in);
        String answer=scanner.nextLine();
        return answer;
    }
    public static Documents fill(){

        int ISBN=InputUtil.enterInt("enter ISBN\n");
        String titre =InputUtil.enterString("enter titre\n");
        String auteurs =InputUtil.enterString("enter auteur\n");
        String editeurs =InputUtil.enterString("enter editeur\n");
        int ann_edition=InputUtil.enterInt("enter annee d'edition\n");
        int nb_exp=InputUtil.enterInt("enter nombre exemplaire\n");
        int numero= Bibliotheque.documents.length;
        return new Documents(ISBN,titre,auteurs,editeurs,ann_edition,nb_exp);
    }
    public static Etudiant fillE(){
        String genre=InputUtil.enterString("enter le genre\n");
        String nom =InputUtil.enterString("enter le nom\n");
        String prenom =InputUtil.enterString("enter le prenom\n");
        String profession =InputUtil.enterString("enter profession\n");
        String cne=InputUtil.enterString("enter le cne\n");
        int nb_doc=InputUtil.enterInt("enter nombre de document emprunte\n");
        Documents doc_emprunte= new Documents(fill().getISBN(), fill().getTitre(), fill().auteurs, fill().getEditeur(), fill().getAnn_edition(), fill().nb_exp);

        return new Etudiant(genre,nom,prenom,profession,cne, (Livre) doc_emprunte,nb_doc);
    }
    public static Professeur fillP(){
        String genre=InputUtil.enterString("enter le genre\n");
        String nom =InputUtil.enterString("enter le nom\n");
        String prenom =InputUtil.enterString("enter le prenom\n");
        String profession =InputUtil.enterString("enter profession\n");
        String cin=InputUtil.enterString("enter le cin\n");
        int nb_doc=InputUtil.enterInt("enter nombre de livre emprunte\n");
        Documents doc_emprunte= new Documents(fill().getISBN(), fill().getTitre(), fill().auteurs, fill().getEditeur(), fill().getAnn_edition(), fill().nb_exp);
        return new Professeur(genre,nom,prenom,profession,doc_emprunte,nb_doc,cin);
    }



}
