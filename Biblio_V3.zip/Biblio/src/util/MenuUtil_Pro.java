package util;

import Personne.Personne;
import main.Bibliotheque;
import Personne.Professeur;

import java.util.Arrays;

public class MenuUtil_Pro {
    public static void printAllEmp(){
        if(Bibliotheque.emprunteursP==null){
            System.out.println("you do not have any emp\n");
            return;
        }
        System.out.println("Professor that you have :\n");
        for (int i=0;i<Bibliotheque.emprunteursP.length;i++){
            Personne P= Bibliotheque.emprunteursP[i];
            System.out.println((1+i)+".document\n"+P.toString());
        }
    }
    public static void registerEmpPro(){
        int count=InputUtil.enterInt("how many Adherent do you want to register?\n");
        Bibliotheque.emprunteursP=new Professeur[count];
        for (int i=0;i<count;i++){
            System.out.println((i+1)+"-Register");
            Professeur P=InputUtil.fillP();
            Bibliotheque.emprunteursP[i]=P;
        }
    }
    //Professeur getProfesseurByCin(String cin)
    public static void getProfesseurByCin(String cin) {
        System.out.println("enter cin of Professor that you want to find ");
        for (int i = 0; i < Bibliotheque.emprunteursP.length; i++) {
            Professeur pro = Bibliotheque.emprunteursP[i];
            if (pro.getCin().equalsIgnoreCase(cin)) {
                System.out.println(pro.toString());
            } else {
                System.out.println("Professor not found\n");
            }
        }
    }
    public static void suppProfesseur() {
        if (Bibliotheque.emprunteursP == null) {
            System.out.println("you do not have any Professor\n");
            return;
        }
        Professeur[] proArray= Arrays.copyOf(Bibliotheque.emprunteursP,Bibliotheque.emprunteursP.length);
        String cin = InputUtil.enterString("Cin of student that you want to delete?\n");
        for (Professeur p : proArray) {
            if (p!=null && p.getCin().equalsIgnoreCase(cin)) {
                int i= p.getArrayIndexP(Bibliotheque.emprunteursP,p );
                Bibliotheque.emprunteursP[i]=null;

                System.out.println("Professor has been deleted");
            }
        }
    }
}
