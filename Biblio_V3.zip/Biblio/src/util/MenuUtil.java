package util;

import documents.Documents;
import main.Bibliotheque;
import Personne.Etudiant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;



public class MenuUtil {
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////DOCUMENTS///////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static void printAllDoc(){
        if(Bibliotheque.documents==null){
            System.out.println("you do not have any Documents\n");
            return;
        }
        System.out.println("Documents that you have registred:\n");
        for (int i=0;i<Bibliotheque.documents.length;i++) {
            Documents doc = Bibliotheque.documents[i];
            if (doc != null) {
                System.out.println((1 + i) + ".document\n" + doc.getInfo());
            }
        }
    }
    public static void registerDocument(){
        int count=InputUtil.enterInt("how many documents do you want to register?\n");
        Bibliotheque.documents=new Documents[count];// Bibliotheque.documents est un obj d un tab students
        for (int i=0;i<count;i++){
            System.out.println((i+1)+"-Register");
            Documents doc=InputUtil.fill();//st obj dyal student
            Bibliotheque.documents[i]=doc;
        }
    }
    /*public static void ajouterDocument(){
        int count=InputUtil.enterInt("how many documents do you want to register?\n");
        Bibliotheque.documents=new Documents[count];// Bibliotheque.documents est un obj d un tab students
        for (int i=0;i<count;i++){
            System.out.println((i+1)+"-Register");
            Documents doc=InputUtil.fill();//st obj dyal student
            Bibliotheque.documents[i]=doc;
        }
    }*/
    public static void suppDocument() {
        if (Bibliotheque.documents == null) {
            System.out.println("you do not have any Documents\n");
            return;
        }
        Documents[] docArray= Arrays.copyOf(Bibliotheque.documents,Bibliotheque.documents.length);
        String title = InputUtil.enterString("title of documents that you want to delete?\n");
        for (Documents doc : docArray) {
            if (doc!=null &&doc.getTitre().equalsIgnoreCase(title)) {
                int i= doc.getArrayIndex(Bibliotheque.documents,doc );
                Bibliotheque.documents[i]=null;

                System.out.println("documents has been deleted");
            }
        }
    }
    public static void findDocument_title(){
        String find=InputUtil.enterString("enter title that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents st= Bibliotheque.documents[i];
            if(st.getTitre().equalsIgnoreCase(find) ){
                System.out.println(st.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }
        }
    }
    public static void findDocument_aut(){
        String find=InputUtil.enterString("enter auteur that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents st= Bibliotheque.documents[i];
            if(st.getAuteurs().equalsIgnoreCase(find) ){
                System.out.println(st.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }
        }
    }
    public static void findDocument_ISBN(){
        int find=InputUtil.enterInt("enter ISBN that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents doc= Bibliotheque.documents[i];
            if(doc.getISBN()==find ){
                System.out.println(doc.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }
        }
    }
    public static void findDocument_editeur(){
        String find=InputUtil.enterString("enter editeur that you want to find ;\n");
        for (int i=0;i<Bibliotheque.documents.length;i++){
            Documents doc= Bibliotheque.documents[i];
            if(doc.getEditeur().equalsIgnoreCase(find) ){
                System.out.println(doc.getInfo());
            }
            else {
                System.out.println("Document not found\n");
            }
        }
    }
    public static void updateStudent(){
        int update=InputUtil.enterInt("In which Document you want to update:\n");
        System.out.println("Enter new information:\n");
        Documents st=InputUtil.fill();
        Bibliotheque.documents[update-1]=st;
        System.out.println(st.getInfo());
    }
    //Document[] TrierAnneeAsc()
    public static void TrierAnneeAsc(){
        Documents[] docArray= Arrays.copyOf(Bibliotheque.documents,Bibliotheque.documents.length);
        if(docArray.length==1){
            System.out.println("vous avez qu'un seul element ");
            System.out.println(docArray[0] + " \n ");
        }else {
            for (int i = 0; i < docArray.length - 1; i++) {
                int index = i;
                for (int j = i + 1; j < docArray.length; j++) {
                    if (docArray[j].ann_edition < docArray[index].ann_edition) {
                        index = j;
                    }
                }
                int min = docArray[index].ann_edition;
                docArray[index].ann_edition = docArray[i].ann_edition;
                docArray[i].ann_edition = min;
                for (int x = 0; x < docArray.length; x++) {
                    System.out.print(docArray[x] + " \n ");
                }
                System.out.println();
            }
        }
    }
    //Document[] TrierAnneeDesc()
    public static void  TrierAnneeDesc(){
        Documents[] docmArray= Arrays.copyOf(Bibliotheque.documents,Bibliotheque.documents.length);
        if(docmArray.length==1){
            System.out.println("vous avez qu'un seul element ");
            System.out.println(docmArray[0] + " \n ");
        }else {
            for (int i = 0; i < docmArray.length - 1; i++) {
                int index = i;
                for (int j = i + 1; j < docmArray.length; j++) {
                    if (docmArray[j].ann_edition > docmArray[index].ann_edition) {
                        index = j;
                    }
                }
                int min = docmArray[index].ann_edition;
                docmArray[index].ann_edition = docmArray[i].ann_edition;
                docmArray[i].ann_edition = min;
                for (int x = 0; x < docmArray.length; x++) {
                    System.out.print(docmArray[x] + " \n ");
                }
                System.out.println();
            }
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////PERSONNES///////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


}
