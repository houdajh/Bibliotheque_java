package main;

import Personne.Etudiant;
import Personne.Personne;
import documents.Documents;
import Personne.Professeur;

import java.util.ArrayList;

public class Bibliotheque {
    public static Documents[] documents=null;
    public static Etudiant[] emprunteursE=null;
    public static Professeur[] emprunteursP=null;

}
