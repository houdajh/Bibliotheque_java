package Personne;

import documents.Documents;
import documents.Livre;

public class Professeur extends Personne {

    public String cin;
    public Documents doc_emprunte;

    public Professeur(String genre, String nom ,String prenom, String profession, Documents doc_emprunte, int nb_doc, String cin) {
        super(genre,nom,prenom, profession,nb_doc);
        this.cin= cin;
        this.doc_emprunte= doc_emprunte;
    }

    public String getCin() {
        return cin;
    }
    public Documents getLiv_emprunte() {
        return doc_emprunte;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }
    public void setLiv_emprunte(Documents doc_emprunte) {
        this.doc_emprunte = doc_emprunte;
    }
    public int getArrayIndexP(Professeur[] arr, Professeur value) {

        int k = 0;
        for (int i = 0; i < arr.length; i++) {

            if (arr[i] == value) {
                k = i;
                break;
            }
        }
        return k;
    }
}

