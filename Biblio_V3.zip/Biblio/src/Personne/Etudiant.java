package Personne;

import documents.Documents;
import documents.Livre;

public class Etudiant extends Personne {
    public String cne;
    public Documents doc_emprunte;

    public Etudiant(String genre, String nom, String prenom, String profession, String cne, Livre Liv_emprunte, int nb_doc) {
        super(genre, nom, prenom, profession, nb_doc);
        this.cne = cne;
        this.doc_emprunte = doc_emprunte;
    }


    public String getCne() {
        return cne;
    }

    public Documents getLiv_emprunte() {
        return doc_emprunte;
    }

    public void setCne(String cne) {
        this.cne = cne;
    }

    public void setDoc_emprunte(Documents doc_emprunte) {
        this.doc_emprunte = doc_emprunte;
    }

    public int getArrayIndexE(Etudiant[] arr, Etudiant value) {

        int k = 0;
        for (int i = 0; i < arr.length; i++) {

            if (arr[i] == value) {
                k = i;
                break;
            }
        }
        return k;
    }
}
