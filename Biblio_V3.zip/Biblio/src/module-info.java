module houda.wissal {

    requires  javafx.fxml;
    requires  javafx.controls;
    requires javafx.graphics;

    opens sample;

}